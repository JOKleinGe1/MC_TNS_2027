
// Auteur :
// Groupe :
// Année  :

#include "main.h"
#include <math.h>

uint32_t filtre_suiveur(uint32_t Xin)
{
	uint32_t y = Xin;
	return y;
}


uint32_t filtreRC (uint32_t Xin)
{
	uint32_t y = Xin;
	return y;
}

uint32_t filtre_RII_butter (uint32_t Xin)
{
	uint32_t y = Xin;
	return y;
}


uint32_t filtre_RIF (uint32_t Xin)
{
	uint32_t y = Xin;
	return y;
}


uint32_t mon_meilleur_filtre (uint32_t Xin)
{
	uint32_t y = Xin;
	return y;
}
