#ifndef INC_FILTRE_H_
#define INC_FILTRE_H_

uint32_t filtre_suiveur		(uint32_t Xin);
uint32_t filtreRC 			(uint32_t Xin);
uint32_t filtre_RII_butter 	(uint32_t Xin);
uint32_t filtre_RIF			(uint32_t Xin);
uint32_t mon_meilleur_filtre 	(uint32_t Xin);

#endif /* INC_FILTRE_H_ */
